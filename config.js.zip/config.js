let config = {
  host: 'ec2-18-216-101-119.us-east-2.compute.amazonaws.com',
  user: 'm3sheng',
  password: 'Mc1234567',
  database: 'm3sheng'
};

module.exports = config;